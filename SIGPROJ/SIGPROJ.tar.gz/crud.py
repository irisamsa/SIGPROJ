 # -*- coding: utf-8 -*-

from easygui import multenterbox, msgbox, passwordbox, choicebox, buttonbox, textbox
from peewee import *

#=======================
# BANCO DE DADOS
#=======================

from peewee import Expression # the building block for expressions

OP_MOD = 'mod'
OP_REGEXP = 'regexp'

def mod(lhs, rhs):
    return Expression(lhs, OP_MOD, rhs)

def regexp(lhs, rhs):
    return Expression(lhs, OP_REGEXP, rhs)

SqliteDatabase.register_ops({OP_MOD: '%', OP_REGEXP: 'REGEXP'})

db = SqliteDatabase('sgpp.db', threadlocals=True)

#=======================
# TABELAS
#=======================

class MPesquisador(Model):
    nome = CharField()
    telefone = CharField()
    endereco = CharField()
    email = CharField()
    curriculo = CharField()

    class Meta: 
		database = db

class MProjeto(Model):
	titulo = CharField()
	coordenador = CharField()
	resumo = CharField()
	keywords = CharField()
	inicio = CharField()
	final = CharField()

	class Meta: 
		database = db

class MParticipante(Model):
	projeto = CharField()
	pesquisador = CharField()
		
	class Meta:
		database = db

#=======================
# FUNCOES AUXILIARES
#=======================
import unicodedata

def remover_acentos(s):
	if isinstance(s, unicode):
		return ''.join((c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c)  != 'Mn'))
	else:
		return s
     
def array_to_ascii(lista):
	for i in range(len(lista)):
		lista[0] = remover_acentos(lista[0])
	return lista

#=======================
# FUNCOES DO SISTEMA
#=======================
title = "SISTEMA DE GESTAO DE PROJETOS DE PESQUISA (SIGPROJ)"

def login():

	msg = "Entre com a senha para acesso."
	for i in range(3):
		senha = passwordbox(msg, title, default='', image=None, root=None)
		if senha == "pesquisa@2015": return True
		else: 
			msgbox(msg="Senha Incorreta! Tente novamente.", title=title, ok_button='Continuar', image=None, root=None)
	return False
		
def cadastrar_pesquisador():
	title = "Cadastrar Pesquisador"
	msg = "Entre com os dados do pesquisador: "
	fieldNames = ["Nome Completo: ","Telefone: ","Endereco: ","E-mail: ", "Mini-CV: "]
	fieldValues = []
	fieldValues = multenterbox(msg, title, fieldNames)
	
	while 1:
		if fieldValues == None: break
		errmsg = ""
		for i in range(len(fieldNames)):
		  if fieldValues[i].strip() == "":
			errmsg = errmsg + ('"%s" e um campo requisido.\n\n' % fieldNames[i])
		if errmsg == "": break # no problems found
		fieldValues = multenterbox(errmsg, title, fieldNames, fieldValues)
	
	if fieldValues == None: 
		return
	else:
		#Tira acentos
		fieldValues = array_to_ascii(fieldValues)
		
		#Converte para Maiúsculo o Nome do Pesquisador
		fieldValues[0] = fieldValues[0].upper()
		
		pesquisador = MPesquisador.create(nome=fieldValues[0], telefone=fieldValues[1], endereco=fieldValues[2], email=fieldValues[3], curriculo=fieldValues[4])
		pesquisador.save()
		msgbox(msg="Pesquisador(a): " + fieldValues[0] + " cadastrado(a) com sucesso!", title=title, ok_button='Continuar', image=None, root=None)
	return

def editar_pesquisador():
	pesquisadores = [x.nome for x in MPesquisador.select().order_by(MPesquisador.nome)]
	
	msg ="Selecione um pesquisador para editar."
	title = "Pesquisador - Editar"
	pesquisador = choicebox(msg, title, pesquisadores)
	
	if pesquisador == None: return
	
	pesquisador = MPesquisador.get(MPesquisador.nome == pesquisador)
	
	msg ="Entre com as alteracoes."
	fieldNames = ["Nome Completo: ","Telefone: ","Endereco: ","E-mail: ", "Mini-CV: "]
	fieldValues = [pesquisador.nome, pesquisador.telefone, pesquisador.endereco, pesquisador.email, pesquisador.curriculo]
	
	fieldValues = multenterbox(msg, title, fieldNames, fieldValues)
	
	if fieldValues == None: return
	
	#Tira acentos
	fieldValues = array_to_ascii(fieldValues)
		
	#Converte para Maiúsculo o Nome do Pesquisador
	fieldValues[0] = fieldValues[0].upper()
	
	pesquisador.nome = fieldValues[0]
	pesquisador.telefone = fieldValues[1]
	pesquisador.endereco = fieldValues[2]
	pesquisador.email = fieldValues[3]
	pesquisador.curriculo = fieldValues[4]
	pesquisador.save()
	msgbox(msg="Pesquisador(a): " + fieldValues[0] + " atualizado(a) com sucesso!", title=title, ok_button='Continuar', image=None, root=None)

	return
	

def cadastrar_projeto():
	
	pesquisadores = [x.nome for x in MPesquisador.select().order_by(MPesquisador.nome)]
	
	msg ="Selecione o Coordenador do Projeto."
	title = "Cadastro de Projeto"
	coordenador = choicebox(msg, title, pesquisadores)

	if coordenador == None: return

	msg = "Entre com os dados do Projeto: "
	fieldNames = ["Titulo: ","Resumo: ","Palavras-chave: ", "Ano de Início: ", "Ano de Término: "]
	fieldValues = []
	fieldValues = multenterbox(msg, title, fieldNames)
	
	while 1:
		if fieldValues == None: break
		errmsg = ""
		for i in range(len(fieldNames)):
		  if fieldValues[i].strip() == "":
			errmsg = errmsg + ('"%s" e um campo requisido.\n\n' % fieldNames[i])
		if errmsg == "": break # no problems found
		fieldValues = multenterbox(errmsg, title, fieldNames, fieldValues)
	
	if fieldValues == None: 
		return
	else:
		#Tira acentos
		fieldValues = array_to_ascii(fieldValues)
		
		#Converte para Maiúsculo o Titulo do Projeto
		fieldValues[0] = fieldValues[0].upper()
		
		projeto = MProjeto.create(titulo=fieldValues[0], coordenador=coordenador, resumo=fieldValues[1], keywords=fieldValues[2], inicio=fieldValues[3], final=fieldValues[4])
		projeto.save()
		msgbox(msg="Projeto: " + fieldValues[0] + " cadastrado(a) com sucesso!", title=title, ok_button='Continuar', image=None, root=None)
	return


def editar_projeto():
	projetos = [x.titulo for x in MProjeto.select().order_by(MProjeto.titulo)]
	
	msg ="Selecione um projeto para editar."
	title = "Projeto - Editar"
	projeto = choicebox(msg, title, projetos)
	
	if projeto == None: return
	
	projeto = MProjeto.get(MProjeto.titulo == projeto)
	
	msg ="Entre com as alteracoes."
	fieldNames = ["Titulo: ","Coordenador: ", "Resumo: ", "Palavras-chave: ", "Ano de Início: ", "Ano de Término: "]
	fieldValues = [projeto.titulo, projeto.coordenador, projeto.resumo, projeto.keywords, projeto.inicio, projeto.final]
	
	fieldValues = multenterbox(msg, title, fieldNames, fieldValues)
	
	if fieldValues == None: return 
	
	#Tira acentos
	fieldValues = array_to_ascii(fieldValues)
		
	#Converte para Maiúsculo o Nome do Pesquisador
	fieldValues[0] = fieldValues[0].upper()
	
	projeto.titulo = fieldValues[0]
	projeto.coordenador = fieldValues[1]
	projeto.resumo = fieldValues[2]
	projeto.keywords = fieldValues[3]
	projeto.inicio = fieldValues[4]
	projeto.final = fieldValues[5]
	projeto.save()
	msgbox(msg="Projeto: " + fieldValues[0] + " atualizado(a) com sucesso!", title=title, ok_button='Continuar', image=None, root=None)

	return

def adicionar_participante():
	pesquisadores = [x.nome for x in MPesquisador.select().order_by(MPesquisador.nome)]
	
	msg ="Selecione um pesquisador para adicionar como participante em projeto."
	title = "Projeto - Adicionar Participante"
	pesquisador = choicebox(msg, title, pesquisadores)
	
	if pesquisador == None: return
	
	projetos = [x.titulo for x in MProjeto.select().order_by(MProjeto.titulo)]
	
	msg ="Selecione o projeto para adicionar pesquisador como participante."
	title = "Projeto - Adicionar Participante"
	projeto = choicebox(msg, title, projetos)
	
	if projeto == None: return
	
	participante = MParticipante.create(projeto=projeto, pesquisador=pesquisador)
	participante.save()
	
	msgbox(msg="O pesquisador: " + pesquisador + " agora participa no projeto: " + projeto + ".", title=title, ok_button='Continuar', image=None, root=None)
	
	return 

def relatorio_projeto():
	projetos = [x.titulo for x in MProjeto.select().order_by(MProjeto.titulo)]
	
	msg ="Selecione o projeto para gerar o relatório."
	title = "Relatório - Projeto"
	projeto = choicebox(msg, title, projetos)
	
	if projeto == None: return
	
	projeto = MProjeto.get(MProjeto.titulo == projeto)
	
	relatorio = "Titulo: " + projeto.titulo + "\n\n"
	relatorio += "Coordenador: " + projeto.coordenador + "\n\n"
	relatorio += "Resumo: " + projeto.resumo + "\n\n"
	relatorio += "Palavras-chave: " + projeto.keywords + "\n\n"	
	
	participantes = [x.pesquisador for x in MParticipante.select().where(MParticipante.projeto == projeto).order_by(MParticipante.pesquisador)]
	
	if participantes:
		relatorio += "Participantes: \n"
		for i in participantes: 
			relatorio +=  i + "\n"
		relatorio += "\n\n"	
	
	textbox("Relatório de Projeto", "Relatorio - Projeto", (relatorio))
	
	return
	

def relatorio_pesquisadores():
	pesquisadores = [x.nome for x in MPesquisador.select().order_by(MPesquisador.nome)]
	
	msg ="Selecione o pesquisador para gerar o relatorio."
	title = "Relatorio de Pesquisadores"
	opcao = choicebox(msg, title, pesquisadores)
	

def menu():
	question="Selecione a opcao desejada: "
	choices = [
	"Pesquisador - Cadastrar", 
	"Pesquisador - Editar", 
	"Projeto - Cadastrar", 
	"Projeto - Editar", 
	"Projeto - Adicionar Participante", 
	"Projeto - Remover Participante", 
	"Relatorio - Pesquisador",
	"Relatorio - Pesquisadores", 
	"Relatorio - Projeto", 
	"Relatorio - Projetos",
	"Configuracoes", 
	"Sair do Sistema"]
	
	while 1: 
		opcao = choicebox(question, title, choices);
		print opcao
		
		if opcao == "Pesquisador - Cadastrar":
			cadastrar_pesquisador()
		
		if opcao == "Pesquisador - Editar":
			editar_pesquisador()
		
		if opcao == "Projeto - Cadastrar":
			cadastrar_projeto()
			
		if opcao == "Projeto - Editar":
			editar_projeto()
		
		if opcao == "Projeto - Adicionar Participante":
			adicionar_participante()
						
		if opcao == "Projeto - Remover Participante":
			pass
		
		if opcao == "Relatorio - Pesquisador":
			pass
		
		if opcao == "Relatorio - Pesquisadores":
			relatorio_pesquisadores()
			
		if opcao == "Relatorio - Projeto":
			relatorio_projeto()
		
		if opcao == "Relatorio - Projetos":
			pass
		
		if opcao == "Configuracoes":
			pass
			
		if opcao == None or opcao == "Sair do Sistema":
			return
	
def tela_inicial():
	image = "ifce.jpeg"
	msg = "SISTEMA DE GESTAO DE PROJETOS DE PESQUISA\n\nTecle 'enter' para continuar."
	choices = ["Continuar..."]
	reply = buttonbox(msg, image=image, choices=choices)

if __name__ == "__main__":
	#MPesquisador.create_table()
	#MProjeto.create_table()
	#MParticipante.create_table()
	
	menu()
	
	#tela_inicial()
	#if login() == True:
	#	menu()
	#else:
	#	exit
		
